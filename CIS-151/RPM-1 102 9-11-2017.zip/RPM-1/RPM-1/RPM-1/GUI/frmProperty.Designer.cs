﻿namespace RPM_1
{
    partial class frmProperty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBxPropNo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBxPropName = new System.Windows.Forms.TextBox();
            this.txtBxPropAddress1 = new System.Windows.Forms.TextBox();
            this.txtBxPropValue = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.txtBxAll = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cboType = new System.Windows.Forms.ComboBox();
            this.grpResidential = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtBxType = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtBxLawnCost = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBxAcreage = new System.Windows.Forms.TextBox();
            this.grpCommercial = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtBxLotCost = new System.Windows.Forms.TextBox();
            this.txtBxSecurityCost = new System.Windows.Forms.TextBox();
            this.grpResidential.SuspendLayout();
            this.grpCommercial.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtBxPropNo
            // 
            this.txtBxPropNo.Location = new System.Drawing.Point(188, 84);
            this.txtBxPropNo.Name = "txtBxPropNo";
            this.txtBxPropNo.Size = new System.Drawing.Size(96, 26);
            this.txtBxPropNo.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(76, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Property No";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Property Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 18);
            this.label3.TabIndex = 3;
            this.label3.Text = "Property Address1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(52, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 18);
            this.label4.TabIndex = 4;
            this.label4.Text = "Property Value";
            // 
            // txtBxPropName
            // 
            this.txtBxPropName.Location = new System.Drawing.Point(189, 130);
            this.txtBxPropName.Name = "txtBxPropName";
            this.txtBxPropName.Size = new System.Drawing.Size(200, 26);
            this.txtBxPropName.TabIndex = 5;
            // 
            // txtBxPropAddress1
            // 
            this.txtBxPropAddress1.Location = new System.Drawing.Point(189, 172);
            this.txtBxPropAddress1.Name = "txtBxPropAddress1";
            this.txtBxPropAddress1.Size = new System.Drawing.Size(199, 26);
            this.txtBxPropAddress1.TabIndex = 6;
            // 
            // txtBxPropValue
            // 
            this.txtBxPropValue.Location = new System.Drawing.Point(189, 211);
            this.txtBxPropValue.Name = "txtBxPropValue";
            this.txtBxPropValue.Size = new System.Drawing.Size(94, 26);
            this.txtBxPropValue.TabIndex = 7;
            this.txtBxPropValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(188, 257);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(95, 36);
            this.btnAdd.TabIndex = 8;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(2, 447);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(0, 18);
            this.lblStatus.TabIndex = 9;
            // 
            // txtBxAll
            // 
            this.txtBxAll.Location = new System.Drawing.Point(42, 312);
            this.txtBxAll.Multiline = true;
            this.txtBxAll.Name = "txtBxAll";
            this.txtBxAll.ReadOnly = true;
            this.txtBxAll.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtBxAll.Size = new System.Drawing.Size(348, 85);
            this.txtBxAll.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(63, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 18);
            this.label5.TabIndex = 11;
            this.label5.Text = "Property Type";
            // 
            // cboType
            // 
            this.cboType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboType.FormattingEnabled = true;
            this.cboType.Items.AddRange(new object[] {
            "Commercial",
            "Residential"});
            this.cboType.Location = new System.Drawing.Point(187, 40);
            this.cboType.Name = "cboType";
            this.cboType.Size = new System.Drawing.Size(157, 26);
            this.cboType.TabIndex = 12;
            this.cboType.SelectedIndexChanged += new System.EventHandler(this.cboType_SelectedIndexChanged);
            // 
            // grpResidential
            // 
            this.grpResidential.Controls.Add(this.txtBxAcreage);
            this.grpResidential.Controls.Add(this.label8);
            this.grpResidential.Controls.Add(this.txtBxLawnCost);
            this.grpResidential.Controls.Add(this.label7);
            this.grpResidential.Controls.Add(this.txtBxType);
            this.grpResidential.Controls.Add(this.label6);
            this.grpResidential.Enabled = false;
            this.grpResidential.Location = new System.Drawing.Point(483, 28);
            this.grpResidential.Name = "grpResidential";
            this.grpResidential.Size = new System.Drawing.Size(282, 152);
            this.grpResidential.TabIndex = 13;
            this.grpResidential.TabStop = false;
            this.grpResidential.Text = "Residential";
            this.grpResidential.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 18);
            this.label6.TabIndex = 0;
            this.label6.Text = "Type";
            // 
            // txtBxType
            // 
            this.txtBxType.Location = new System.Drawing.Point(106, 32);
            this.txtBxType.Name = "txtBxType";
            this.txtBxType.Size = new System.Drawing.Size(136, 26);
            this.txtBxType.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 18);
            this.label7.TabIndex = 2;
            this.label7.Text = "Lawn $";
            // 
            // txtBxLawnCost
            // 
            this.txtBxLawnCost.Location = new System.Drawing.Point(106, 64);
            this.txtBxLawnCost.Name = "txtBxLawnCost";
            this.txtBxLawnCost.Size = new System.Drawing.Size(124, 26);
            this.txtBxLawnCost.TabIndex = 3;
            this.txtBxLawnCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 105);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 18);
            this.label8.TabIndex = 4;
            this.label8.Text = "Acreage";
            // 
            // txtBxAcreage
            // 
            this.txtBxAcreage.Location = new System.Drawing.Point(106, 97);
            this.txtBxAcreage.Name = "txtBxAcreage";
            this.txtBxAcreage.Size = new System.Drawing.Size(90, 26);
            this.txtBxAcreage.TabIndex = 5;
            this.txtBxAcreage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // grpCommercial
            // 
            this.grpCommercial.Controls.Add(this.txtBxSecurityCost);
            this.grpCommercial.Controls.Add(this.txtBxLotCost);
            this.grpCommercial.Controls.Add(this.label10);
            this.grpCommercial.Controls.Add(this.label9);
            this.grpCommercial.Enabled = false;
            this.grpCommercial.Location = new System.Drawing.Point(488, 213);
            this.grpCommercial.Name = "grpCommercial";
            this.grpCommercial.Size = new System.Drawing.Size(276, 162);
            this.grpCommercial.TabIndex = 14;
            this.grpCommercial.TabStop = false;
            this.grpCommercial.Text = "Commercial";
            this.grpCommercial.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(125, 18);
            this.label9.TabIndex = 0;
            this.label9.Text = "Parking Lot Cost";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 82);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 18);
            this.label10.TabIndex = 1;
            this.label10.Text = "Security Cost";
            // 
            // txtBxLotCost
            // 
            this.txtBxLotCost.Location = new System.Drawing.Point(153, 29);
            this.txtBxLotCost.Name = "txtBxLotCost";
            this.txtBxLotCost.Size = new System.Drawing.Size(113, 26);
            this.txtBxLotCost.TabIndex = 2;
            this.txtBxLotCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtBxSecurityCost
            // 
            this.txtBxSecurityCost.Location = new System.Drawing.Point(153, 73);
            this.txtBxSecurityCost.Name = "txtBxSecurityCost";
            this.txtBxSecurityCost.Size = new System.Drawing.Size(112, 26);
            this.txtBxSecurityCost.TabIndex = 3;
            this.txtBxSecurityCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // frmProperty
            // 
            this.AcceptButton = this.btnAdd;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(833, 474);
            this.Controls.Add(this.grpCommercial);
            this.Controls.Add(this.grpResidential);
            this.Controls.Add(this.cboType);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtBxAll);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtBxPropValue);
            this.Controls.Add(this.txtBxPropAddress1);
            this.Controls.Add(this.txtBxPropName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtBxPropNo);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmProperty";
            this.Text = "RPM Property";
            this.grpResidential.ResumeLayout(false);
            this.grpResidential.PerformLayout();
            this.grpCommercial.ResumeLayout(false);
            this.grpCommercial.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBxPropNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBxPropName;
        private System.Windows.Forms.TextBox txtBxPropAddress1;
        private System.Windows.Forms.TextBox txtBxPropValue;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.TextBox txtBxAll;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cboType;
        private System.Windows.Forms.GroupBox grpResidential;
        private System.Windows.Forms.TextBox txtBxAcreage;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtBxLawnCost;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtBxType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox grpCommercial;
        private System.Windows.Forms.TextBox txtBxSecurityCost;
        private System.Windows.Forms.TextBox txtBxLotCost;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
    }
}

